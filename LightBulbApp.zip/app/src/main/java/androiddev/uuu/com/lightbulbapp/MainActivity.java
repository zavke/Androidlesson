package androiddev.uuu.com.lightbulbapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    private ImageView lightBulbImage;
    private SeekBar lightBulbSeekBar;
    private Switch lightBulbSwitcher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lightbulb);
        initView();
        initHandler();
    }



    private void initHandler() {
        //Homework
    }
    private void initView() {
        lightBulbImage = (ImageView) findViewById(R.id.iv_lightBulb);
        lightBulbSeekBar = (SeekBar) findViewById(R.id.sb_alpha);
        lightBulbSwitcher = (Switch) findViewById(R.id.sw_power);

        lightBulbImage.setVisibility(View.INVISIBLE);
        lightBulbSeekBar.setEnabled(false);
    }
}
