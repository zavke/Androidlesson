package androiddev.uuu.com.demo3_eventhandler;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

public class MainActivity extends AppCompatActivity {
    //Step1
    private EditText nameInput;
    private Button sayHelloBtn;
    private TextView display;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        //Step2
        initView();
        //Step3
        initHandler();


    }

    private void initHandler() {
        sayHelloBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = nameInput.getText().toString();
                display.setText("Hello "+text);
            }
        });
    }


    private void initView() {
        nameInput = (EditText) findViewById(R.id.et_nameInput);
        sayHelloBtn = (Button) findViewById(R.id.btn_sayHello);
        display = (TextView) findViewById(R.id.tv_display);
        display.setText("");
    }


}
