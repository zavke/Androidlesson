
public class Outter {
	//instance variable, object-level
	public int idx;
	//inner class : ���� instance variable
	public class Inner{
		public void test(){
			idx = 100;
			Outter.this.idx = 109;
			System.out.println(idx);
		}
	}
	
	//static , class-level
	public static int count;
	public static void stest(){
		//idx = 0; can not access instance-level members
		count++;
	}
	public static class StaticInner{
		public void increment(){
			count++;
			System.out.println(count);
		}
	}
	
	public void localMethod(final int amt){
		//amt = 10;//local variable : pass by copy
		class Local{//Local variable
			public void localM(){
				System.out.println(idx);
				System.out.println(amt);
			}
		}
	}
}

