
public class TestStaticNestedClass {

	public static void main(String [] args){
		System.out.println(Outter.count);
		Outter.count = 9;
		Outter.stest();
		System.out.println(Outter.count);
		Outter.StaticInner si = new Outter.StaticInner();
		si.increment();
		si.increment();
		
	}
}
