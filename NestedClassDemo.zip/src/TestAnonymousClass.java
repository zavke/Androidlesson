
public class TestAnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// A a = new A();
		//Standard
		IAImpl o1 = new IAImpl(); 
		AImpl o2 = new AImpl();
		//Anonymous class
		IA o3 = new IA(){
			@Override
			public void mA() {
				// TODO Auto-generated method stub

			}
		};
			
		A o4 = new A(){
			@Override
			void mA() {
					// TODO Auto-generated method stub
					
			}
		};
	}

}
interface IA{
	void mA();
}

abstract class A{
	abstract void mA();
}
class AImpl extends A{
	@Override
	void mA() {
		// TODO Auto-generated method stub
	}
}
class IAImpl implements IA{
	@Override
	public void mA() {
		// TODO Auto-generated method stub
	}
}

