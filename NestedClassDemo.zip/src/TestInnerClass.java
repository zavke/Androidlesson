
public class TestInnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outter obj = new Outter();
		obj.idx = 10;
		int amt = 99;
		obj.localMethod(amt);
		System.out.println(amt);
		Outter.Inner inner = obj.new Inner();
		inner.test();
		
		System.out.println("Final : "+obj.idx );
	}

}
